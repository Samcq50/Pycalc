def sum(a, b):
    return (a / b)

a = int(input())
b = int(input())

print(f'{sum(a, b)}')